**To log out a user**

The following ``logout-user`` example logs out the specified user. ::

    aws chime logout-user \
        --account-id a1b2c3d4-5678-90ab-cdef-11111EXAMPLE \
        --user-id a1b2c3d4-5678-90ab-cdef-22222EXAMPLE

This command produces no output.
